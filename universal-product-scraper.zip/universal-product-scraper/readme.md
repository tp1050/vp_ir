├── manifest.json
├── content.js
├── extractors/
│   ├── jsonld.js
│   ├── woocommerce.js
│   ├── opengraph.js
├── utils/
│   ├── helpers.js